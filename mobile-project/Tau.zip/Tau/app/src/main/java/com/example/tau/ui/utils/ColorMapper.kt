package com.example.tau.ui.utils

import androidx.compose.ui.graphics.Color
import java.util.Locale

object ColorMapper {
    private val colorMap = mapOf(
        "Rosa" to "#FFB3D9",
        "Vermelho" to "#FF6B6B",
        "Laranja" to "#FFD166",
        "Amarelo" to "#FFE5B4",
        "Verde" to "#A8D8B8",
        "Menta" to "#98FF98",
        "Azul" to "#74B9FF",
        "Ciano" to "#6FD7E6",
        "Roxo" to "#DDA0DD",
        "Lavanda" to "#E6D7FF",
        "Salmão" to "#FFB3BA",
        "Pêssego" to "#FFCBB1"
    )

    fun colorNameToHex(colorName: String): String {
        val normalized = colorName.trim().replace("#", "")
        val directHex = if (normalized.length == 6 || normalized.length == 8) "#$normalized" else null
        if (directHex != null && directHex.matches(Regex("^#[0-9A-Fa-f]{6,8}$"))) return directHex
        val capitalized = colorName.trim().replaceFirstChar { it.uppercase(Locale.ROOT) }
        return colorMap[colorName] ?: colorMap[capitalized] ?: "#000000"
    }

    fun colorNameToColor(colorName: String): Color {
        return try {
            val hex = colorNameToHex(colorName)
            Color(android.graphics.Color.parseColor(hex))
        } catch (_: Exception) {
            Color(0xFF000000)
        }
    }
}
