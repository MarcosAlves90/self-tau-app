package com.example.tau.ui.theme

import androidx.compose.ui.unit.dp

internal object Dimensions {
    val screenPadding = 32.dp
    val mediumSpacing = 16.dp
}