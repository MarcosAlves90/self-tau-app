package com.example.tau.data.model

data class Discipline(
    val id: String,
    val title: String,
    val teacher: String,
    val room: String,
    val color: String
)

