package com.example.tau.data.model

data class User(
    val email: String,
    val senha: String? = null,
    val id: Int? = null
)
